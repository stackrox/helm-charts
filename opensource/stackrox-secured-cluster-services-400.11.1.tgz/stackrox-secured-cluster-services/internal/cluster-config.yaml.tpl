{{- if ._rox.clusterName }}
clusterName: {{ ._rox.clusterName }}
{{- end }}
managedBy: {{ ._rox.managedBy }}
clusterConfig:
  staticConfig:
    {{- if not ._rox.env.openshift }}
    type: KUBERNETES_CLUSTER
    {{- else }}
    type: OPENSHIFT4_CLUSTER
    {{- end }}
    mainImage: {{ coalesce ._rox.image.main._abbrevImageRef ._rox.image.main.fullRef }}
    collectorImage: {{ coalesce ._rox.image.collector._abbrevImageRef ._rox.image.collector.fullRef }}
    centralApiEndpoint: {{ ._rox.centralEndpoint }}
    collectionMethod: {{ ._rox.collector.collectionMethod | upper | replace "-" "_" }}
    admissionController: {{ ._rox.admissionControl.listenOnCreates }}
    admissionControllerUpdates: {{ ._rox.admissionControl.listenOnUpdates }}
    admissionControllerEvents: {{ ._rox.admissionControl.listenOnEvents }}
    admissionControllerFailOnError: {{ ._rox.admissionControl._failOnError }}
    tolerationsConfig:
      disabled: {{ ._rox.collector.disableTaintTolerations }}
    slimCollector: false
  dynamicConfig:
    disableAuditLogs: {{ ._rox.auditLogs.disableCollection | not | not }}
    admissionControllerConfig:
      enabled: {{ ._rox.admissionControl.dynamic.enforceOnCreates }}
      timeoutSeconds: {{ ._rox.admissionControl.dynamic.timeout }}
      scanInline: {{ ._rox.admissionControl.dynamic.scanInline }}
      disableBypass: {{ ._rox.admissionControl.dynamic.disableBypass }}
      enforceOnUpdates: {{ ._rox.admissionControl.dynamic.enforceOnUpdates }}
    registryOverride: {{ ._rox.registryOverride }}
    autoLockProcessBaselinesConfig:
      enabled: {{ ._rox.autoLockProcessBaselines.enabled }}
    processIndicators:
      noPersistence: {{ ._rox.processIndicators.noPersistence }}
      excludeOpenshiftNs: {{ ._rox.processIndicators.excludeOpenshiftNs }}
      excludeNamespaceFilter: {{ ._rox.processIndicators.excludeNamespaceFilter | toString }}
  configFingerprint: {{ ._rox._configFP }}
  clusterLabels: {{- toYaml ._rox.clusterLabels | nindent 4 }}
